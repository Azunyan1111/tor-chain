#ifndef _PKTTOOLS_FILTER_H_INCLUDED_
#define _PKTTOOLS_FILTER_H_INCLUDED_

int pkt_filter(char *buffer, int size, int linktype);

#endif
