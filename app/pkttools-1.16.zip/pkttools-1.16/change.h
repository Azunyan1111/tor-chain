#ifndef _PKTTOOLS_CHANGE_H_INCLUDED_
#define _PKTTOOLS_CHANGE_H_INCLUDED_

int pkt_change(char *buffer, int size, int linktype);

#endif
