#ifndef _PKTTOOLS_DISASM_H_INCLUDED_
#define _PKTTOOLS_DISASM_H_INCLUDED_

int pkt_disasm(pkt_asm_list_t list, char *buffer, int size, int linktype);

#endif
