#ifndef _PKTTOOLS_PINGREP_H_INCLUDED_
#define _PKTTOOLS_PINGREP_H_INCLUDED_

int pkt_pingrep(char *buffer, int size, int linktype);

#endif
