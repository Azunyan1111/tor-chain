#ifndef _PKTTOOLS_ASSEMBLE_H_INCLUDED_
#define _PKTTOOLS_ASSEMBLE_H_INCLUDED_

int pkt_assemble(pkt_asm_list_t list, char *buffer, int size, int linktype);

#endif
