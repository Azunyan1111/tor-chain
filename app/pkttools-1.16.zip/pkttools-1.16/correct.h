#ifndef _PKTTOOLS_CORRECT_H_INCLUDED_
#define _PKTTOOLS_CORRECT_H_INCLUDED_

int pkt_correct(char *buffer, int size, int linktype);

#endif
